# Discord License Panel + Node.js API + SQLite

Starter project for a Discord panel with license keys.

## Features
- Discord.js v14 panel with buttons
- Generate 1-day, 7-day, 30-day, or lifetime keys
- Optional Discord-user binding
- Redeem endpoint
- License validation endpoint
- HWID binding
- HWID reset endpoint protected by API secret
- SQLite database
- Expiration and revoke support

## Setup

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Fill in:
   - `DISCORD_TOKEN`
   - `CLIENT_ID`
   - `GUILD_ID`
   - a strong random `API_SECRET`
4. Run:

```bash
npm install
npm start
```

5. In Discord, use:

```text
/panel
/genkey duration:1d
/genkey duration:lifetime
/revoke key:SBX-...
```

Only Discord members with Administrator permission can use the slash commands.

## API examples

Redeem:

```http
POST /api/redeem
Content-Type: application/json

{
  "key": "SBX-...",
  "discordId": "123456789012345678"
}
```

Validate:

```http
POST /api/validate
Content-Type: application/json

{
  "key": "SBX-...",
  "discordId": "123456789012345678",
  "hwid": "device-identifier"
}
```

## Important security note

This is a starter licensing system, not a guarantee that a script can never be copied.

Do NOT put `API_SECRET` inside a client-side script. For stronger protection, use:
- HTTPS
- short-lived signed access tokens
- rate limiting
- server-side script delivery
- logging and revoke controls
- keep the actual script off public/static folders
- avoid putting permanent secrets in the Lua/client code

The `/api/script` route is intentionally disabled until you add a short-lived authenticated token flow.
