const express = require("express");
const multer = require("multer");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const LOADERS = path.join(ROOT, "loaders");

fs.mkdirSync(LOADERS, { recursive: true });

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(ROOT, "public")));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 1024 * 1024 }
});

function makeId() {
  return crypto.randomBytes(12).toString("hex");
}

app.post("/api/upload", upload.single("script"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "File script belum dipilih." });
  }

  const original = req.file.originalname.toLowerCase();
  if (!original.endsWith(".lua") && !original.endsWith(".luau")) {
    return res.status(400).json({ error: "Gunakan file .lua atau .luau." });
  }

  const id = makeId();
  const filename = `${id}.lua`;
  fs.writeFileSync(path.join(LOADERS, filename), req.file.buffer);

  const base = `${req.protocol}://${req.get("host")}`;
  res.json({
    id,
    url: `${base}/v1/loaders/${filename}`
  });
});

app.get("/v1/loaders/:file", (req, res) => {
  const file = req.params.file;

  if (!/^[a-f0-9]{24}\.lua$/.test(file)) {
    return res.status(400).type("text").send("Invalid loader ID.");
  }

  const full = path.join(LOADERS, file);
  if (!fs.existsSync(full)) {
    return res.status(404).type("text").send("Loader not found.");
  }

  res.type("text/plain").send(fs.readFileSync(full, "utf8"));
});

app.listen(PORT, () => {
  console.log(`Loader server running on http://localhost:${PORT}`);
});
