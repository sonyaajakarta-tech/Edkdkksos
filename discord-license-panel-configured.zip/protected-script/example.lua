-- Example protected script placeholder.
-- Keep your real script outside public/static hosting.
print("Protected script loaded after license validation.")
