require("dotenv").config();

const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const Database = require("better-sqlite3");
const {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  Events
} = require("discord.js");

const app = express();
app.use(express.json());

const PORT = Number(process.env.PORT || 3000);
const API_SECRET = process.env.API_SECRET;
const SCRIPT_FILE = path.resolve(process.env.SCRIPT_FILE || "./protected-script/example.lua");

if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID || !process.env.GUILD_ID || !API_SECRET) {
  console.error("Missing required .env values.");
  process.exit(1);
}

const db = new Database("licenses.db");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS licenses (
  key TEXT PRIMARY KEY,
  discord_id TEXT,
  duration TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER,
  hwid TEXT,
  revoked INTEGER NOT NULL DEFAULT 0
);
`);

function makeKey() {
  return "SBX-" + crypto.randomBytes(12).toString("hex").toUpperCase();
}

function durationToMs(duration) {
  const map = {
    "1d": 24 * 60 * 60 * 1000,
    "7d": 7 * 24 * 60 * 60 * 1000,
    "30d": 30 * 24 * 60 * 60 * 1000,
    "lifetime": null
  };
  return map[duration];
}

function licenseStatus(row) {
  if (!row) return { valid: false, reason: "KEY_NOT_FOUND" };
  if (row.revoked) return { valid: false, reason: "REVOKED" };
  if (row.expires_at && Date.now() >= row.expires_at) {
    return { valid: false, reason: "EXPIRED" };
  }
  return { valid: true };
}

function formatExpiry(ms) {
  if (!ms) return "Lifetime";
  return `<t:${Math.floor(ms / 1000)}:F>`;
}

function isAdmin(interaction) {
  return interaction.memberPermissions?.has("Administrator");
}

const commands = [
  new SlashCommandBuilder()
    .setName("panel")
    .setDescription("Send the license panel"),
  new SlashCommandBuilder()
    .setName("genkey")
    .setDescription("Generate a license key")
    .addStringOption(o =>
      o.setName("duration")
       .setDescription("License duration")
       .setRequired(true)
       .addChoices(
         { name: "1 Day", value: "1d" },
         { name: "7 Days", value: "7d" },
         { name: "30 Days", value: "30d" },
         { name: "Lifetime", value: "lifetime" }
       )
    )
    .addUserOption(o =>
      o.setName("user")
       .setDescription("Optional Discord user to bind the key to")
       .setRequired(false)
    ),
  new SlashCommandBuilder()
    .setName("revoke")
    .setDescription("Revoke a license key")
    .addStringOption(o =>
      o.setName("key").setDescription("License key").setRequired(true)
    )
].map(c => c.toJSON());

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

async function registerCommands() {
  const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
  await rest.put(
    Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
    { body: commands }
  );
  console.log("Slash commands registered.");
}

function panelMessage() {
  const embed = new EmbedBuilder()
    .setTitle("🔐 SCRIPT LICENSE PANEL")
    .setDescription(
      "Use the buttons below to manage your license.\n\n" +
      "🔑 **Redeem Key** — activate a key\n" +
      "📜 **Get Script** — receive the protected script after validation\n" +
      "👤 **Get Role** — check your license status\n" +
      "⚙️ **Reset HWID** — administrator action\n" +
      "📊 **Get Stats** — view license information"
    )
    .setFooter({ text: "License System" });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("redeem").setLabel("Redeem Key").setEmoji("🔑").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("script").setLabel("Get Script").setEmoji("📜").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("role").setLabel("Get Role").setEmoji("👤").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("reset").setLabel("Reset HWID").setEmoji("⚙️").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("stats").setLabel("Get Stats").setEmoji("📊").setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row] };
}

client.once(Events.ClientReady, c => {
  console.log(`Logged in as ${c.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      if (!isAdmin(interaction)) {
        return interaction.reply({ content: "❌ Administrator only.", ephemeral: true });
      }

      if (interaction.commandName === "panel") {
        return interaction.reply(panelMessage());
      }

      if (interaction.commandName === "genkey") {
        const duration = interaction.options.getString("duration", true);
        const user = interaction.options.getUser("user", false);
        const key = makeKey();
        const ms = durationToMs(duration);
        const expiresAt = ms ? Date.now() + ms : null;

        db.prepare(`
          INSERT INTO licenses (key, discord_id, duration, created_at, expires_at)
          VALUES (?, ?, ?, ?, ?)
        `).run(key, user?.id || null, duration, Date.now(), expiresAt);

        return interaction.reply({
          content:
            `🔑 **Key:** \`${key}\`\n` +
            `⏱️ **Duration:** ${duration}\n` +
            `👤 **User:** ${user ? `<@${user.id}>` : "Unbound"}\n` +
            `⌛ **Expires:** ${formatExpiry(expiresAt)}`,
          ephemeral: true
        });
      }

      if (interaction.commandName === "revoke") {
        const key = interaction.options.getString("key", true).trim();
        const result = db.prepare("UPDATE licenses SET revoked = 1 WHERE key = ?").run(key);
        return interaction.reply({
          content: result.changes ? "✅ Key revoked." : "❌ Key not found.",
          ephemeral: true
        });
      }
    }

    if (!interaction.isButton()) return;

    const row = db.prepare("SELECT * FROM licenses WHERE discord_id = ? ORDER BY created_at DESC LIMIT 1")
      .get(interaction.user.id);

    if (interaction.customId === "stats" || interaction.customId === "role") {
      if (!row) {
        return interaction.reply({ content: "❌ You don't have a license assigned.", ephemeral: true });
      }

      const status = licenseStatus(row);
      return interaction.reply({
        content:
          `📊 **License**\n` +
          `Status: ${status.valid ? "🟢 Active" : "🔴 " + status.reason}\n` +
          `Duration: ${row.duration}\n` +
          `Expires: ${formatExpiry(row.expires_at)}\n` +
          `HWID: ${row.hwid ? "🔒 Bound" : "⚪ Not bound"}`,
        ephemeral: true
      });
    }

    if (interaction.customId === "redeem") {
      return interaction.reply({
        content: "Send your key to the API endpoint `/api/redeem` with your Discord ID.",
        ephemeral: true
      });
    }

    if (interaction.customId === "script") {
      if (!row) {
        return interaction.reply({ content: "❌ No license assigned.", ephemeral: true });
      }

      const status = licenseStatus(row);
      if (!status.valid) {
        return interaction.reply({ content: `❌ License invalid: ${status.reason}`, ephemeral: true });
      }

      return interaction.reply({
        content: `✅ License valid. Your script can now call the API validation endpoint using its key + HWID.`,
        ephemeral: true
      });
    }

    if (interaction.customId === "reset") {
      if (!isAdmin(interaction)) {
        return interaction.reply({ content: "❌ Administrator only.", ephemeral: true });
      }
      if (!row) {
        return interaction.reply({ content: "❌ No license found for you.", ephemeral: true });
      }
      db.prepare("UPDATE licenses SET hwid = NULL WHERE key = ?").run(row.key);
      return interaction.reply({ content: "✅ HWID reset.", ephemeral: true });
    }
  } catch (err) {
    console.error(err);
    if (!interaction.replied) {
      await interaction.reply({ content: "❌ Internal error.", ephemeral: true });
    }
  }
});

/*
  API:
  POST /api/redeem
  { "key": "...", "discordId": "..." }

  POST /api/validate
  { "key": "...", "discordId": "...", "hwid": "..." }

  POST /api/reset-hwid
  { "key": "..." }
  Header: x-api-secret: YOUR_API_SECRET
*/

app.post("/api/redeem", (req, res) => {
  const { key, discordId } = req.body || {};
  if (!key || !discordId) return res.status(400).json({ ok: false, error: "MISSING_FIELDS" });

  const row = db.prepare("SELECT * FROM licenses WHERE key = ?").get(key.trim());
  const status = licenseStatus(row);

  if (!status.valid) return res.status(403).json({ ok: false, error: status.reason });

  if (row.discord_id && row.discord_id !== discordId) {
    return res.status(403).json({ ok: false, error: "KEY_BOUND_TO_ANOTHER_USER" });
  }

  db.prepare("UPDATE licenses SET discord_id = ? WHERE key = ?").run(discordId, key.trim());
  return res.json({ ok: true, message: "KEY_REDEEMED" });
});

app.post("/api/validate", (req, res) => {
  const { key, discordId, hwid } = req.body || {};
  if (!key || !discordId || !hwid) {
    return res.status(400).json({ ok: false, error: "MISSING_FIELDS" });
  }

  const row = db.prepare("SELECT * FROM licenses WHERE key = ?").get(key.trim());
  const status = licenseStatus(row);

  if (!status.valid) return res.status(403).json({ ok: false, error: status.reason });

  if (row.discord_id && row.discord_id !== discordId) {
    return res.status(403).json({ ok: false, error: "WRONG_DISCORD_USER" });
  }

  if (row.hwid && row.hwid !== hwid) {
    return res.status(403).json({ ok: false, error: "HWID_MISMATCH" });
  }

  if (!row.hwid) {
    db.prepare("UPDATE licenses SET hwid = ? WHERE key = ?").run(hwid, key.trim());
  }

  return res.json({
    ok: true,
    duration: row.duration,
    expiresAt: row.expires_at,
    message: "LICENSE_VALID"
  });
});

app.post("/api/reset-hwid", (req, res) => {
  if (req.headers["x-api-secret"] !== API_SECRET) {
    return res.status(401).json({ ok: false, error: "UNAUTHORIZED" });
  }

  const { key } = req.body || {};
  if (!key) return res.status(400).json({ ok: false, error: "MISSING_KEY" });

  const result = db.prepare("UPDATE licenses SET hwid = NULL WHERE key = ?").run(key.trim());
  return res.json({ ok: !!result.changes });
});

app.get("/api/script", (req, res) => {
  /*
    Deliberately requires a short-lived validation token in a real deployment.
    This starter keeps script delivery separate so you can add your own
    authenticated token flow instead of exposing a permanent script URL.
  */
  return res.status(501).json({
    ok: false,
    error: "SCRIPT_DELIVERY_NOT_ENABLED",
    message: "Validate the license first, then add a short-lived signed download token."
  });
});

app.get("/health", (_, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`API listening on http://localhost:${PORT}`);
});

(async () => {
  await registerCommands();
  await client.login(process.env.DISCORD_TOKEN);
})().catch(err => {
  console.error(err);
  process.exit(1);
});
